import java.util.Scanner;

class Q4{
public static void main(String arg [] ){
 Scanner sc = new Scanner (System.in);
int sum =0;
System.out.println ("Enter n value");
int n = sc.nextInt();
System.out.println ("Enter no value");
int a = sc.nextInt();
System.out.println ("***********");
for(int i=0;i<n;i++)
{
System.out.println((10*i)+a);
}
}
}
