import java.util.Scanner;
class Q6{

static void add()
 {
	Scanner sc = new Scanner(System.in);
	int arr [] = new int[10];
	int sum=0;
	int avg=0;
	for(int i =0; i<arr.length; i++)
	{
	 arr[i] = sc.nextInt();
	} 

	

		for(int i =0; i<arr.length; i++)
		{
	 	 sum = sum + arr[i];
		}
		System.out.println(sum);


		avg = sum/arr.length ;
		System.out.println(avg);
 }




public static void main( String arg [] ){


Q6 ob = new Q6();

 	add();

}
}
