import java.util.Scanner;
class Q8{


void rev(int arr [], int n)
{
int arr1[] = new int[n];
	int j =n;

	for(int i=0;i<n;i++)
{
	
	arr1[j-1 ] = arr[i] ; 
	j = j-1 ; 
}

for(int k=0;k<n;k++)
{
	System.out.println(arr1[k]); 
}

	
}

public static void main(String arg []){
Scanner sc = new Scanner(System.in);
int arr [] = { 10, 20, 30, 40, 50 };


Q8 a = new Q8();
a.rev(arr , arr.length);

}
}