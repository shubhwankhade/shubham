import java.util.Scanner;
class Prime{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
int count = 0;
int n = sc.nextInt();

for(int i=1; i<=n; i++)
{
if (n%i == 0)
count++;
}

if(count == 2)
{
System.out.println("Prime No");
}

else 
{
System.out.println("not a Prime No");
}
}
}