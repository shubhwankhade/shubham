import java.util.Scanner;

class Q1{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);
System.out.println("Enter no : - ");
int n = sc.nextInt();
System.out.println("Enter size: - ");
int p = sc.nextInt();
int t = 0;

System.out.println("************");

for(int i=1; i<=p ;i++)
{
t = n*i;
System.out.println(t);
}

}
}