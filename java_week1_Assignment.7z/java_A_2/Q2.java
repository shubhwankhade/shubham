import java.util.Scanner;

class Q2{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);
int n = sc.nextInt();
int a;
int rev = 0;
while(n>0)
{
	a = n%10;
	n = n/10;
	rev = (rev*10) + a;
}
System.out.println(rev);
}
}