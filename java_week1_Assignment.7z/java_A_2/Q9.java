import java.util.Scanner;
class Q9{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
int n = sc.nextInt();
int arr [] = new int[n];

for(int i=0; i<n;i++)
{
arr [i] = sc.nextInt();
}
System.out.println("****************");

for(int j=0; j<n;j++)
{
System.out.println(arr [j]);
}

System.out.println("Enter the no");
int s = sc.nextInt();

for(int i=0; i<n;i++)
{
 if(s == arr[i])
{
System.out.println("no present in the array");
}
}

}
}