import java.util.Scanner;
class Q10{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);

int arr [] = {1,2,3,4,5,6,7,8,9};
int even = 0;
int odd = 0;
for(int i =0;i<arr.length;i++)
{
	if(arr[i]%2 == 0)
	{
		even += arr[i];	
	}
	
	else
	{
		odd += arr[i];	
	}
	
}

System.out.println(even);
System.out.println(odd);
}
}