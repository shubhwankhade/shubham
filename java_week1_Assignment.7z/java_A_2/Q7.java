import java.util.Scanner;
class Q7{

void sort(int arr[], int n)
{

	for(int i=0; i<n; i++)
	{
		for(int j=i+1; j<n; j++)
			
			if(arr[j]>arr[i])
			{
			 arr[i] = arr[i] + arr[j];
			 arr[j] = arr[i] - arr[j];
			 arr[i] = arr[i] - arr[j];	
			}
	}

	for(int i=0; i<n; i++)
	{
	 System.out.println(arr[i]);
	}
}

public static void main(String arg []){
Scanner sc = new Scanner(System.in);
int arr [] = { 12, 47, 89, 54, 38, 98, 23, 78, 63, 90 };
	Q7 ob = new Q7();
	ob.sort (arr, arr.length);



}
}