import java.util.Scanner;

class Q5{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
int n1 = sc.nextInt();
int n2 = sc.nextInt();
int count;
for(int j=n1; j<=n2; j++)
{
	count = 0;
	for(int i=1; i<=n2; i++)
	{
		if(j%i== 0)
		count++;
	
	}

	if(count == 2)
	{
	 System.out.println(j);
	}
}

}
}