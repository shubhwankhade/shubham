import java.util.Scanner;

class Amstrong{

public static void main(String arg []){

Scanner sc = new Scanner (System.in);
int n = sc.nextInt();
int r, q=0;
while(n>0)
{

r = n%10;
n = n/10;
q += r*r*r;

}

System.out.println(q);
}
}
