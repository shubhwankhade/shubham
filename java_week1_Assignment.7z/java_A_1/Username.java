import java.util.Scanner;

class Username{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);

String s1 = sc.nextLine();

System.out.println("Welcome "+s1);
}
} 
