import java.util.Scanner;
class Leap{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
System.out.println("Enter the year");
int yr=sc.nextInt();

if(((yr % 100 != 0) && (yr % 400 == 0)) || (yr % 4 == 0))
{
System.out.println("it is a leap year");
}

else
{
System.out.println("it is a not leap year");
}
}
}