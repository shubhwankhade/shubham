import java.util.Scanner;

class Intrest{
public static void main(String arg [])
{

Scanner sc = new Scanner(System.in);

double si ,p, r, t;
System.out.println("enter principle amount ");
p = sc.nextDouble();
System.out.println("enter rate ");
r = sc.nextDouble();
System.out.println("enter period ");
t = sc.nextDouble();

si = p*(1+r*t);

System.out.println("Simple Intrest "+si);

}

}
 