import java.util.Scanner;
class Shadi{
public static void main(String arg [])
{
Scanner sc = new Scanner(System.in);
System.out.println("For Male press M and Female press F");
char s1 = sc.next().charAt(0);
System.out.println("Please enter your age");
int age = sc.nextInt();



if (((s1 == 'M') || (s1 == 'm'))&&(age > 21))
{
	System.out.println("eligible for marriage");
}
if (((s1 == 'F')||(s1 == 'n'))&& (age > 18))
{
	System.out.println("eligible for marriage");
}
else
{
	System.out.println("sorry you anr not eligible for marriage");
}

}
}
