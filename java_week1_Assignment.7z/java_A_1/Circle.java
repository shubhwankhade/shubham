import java.util.Scanner;
class Circle{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);
float r = sc.nextFloat();
float area;
area = (float) (3.14*r*r);
float circumferance;
circumferance = (float) (4*3.14*r);

System.out.println("Area of circle -"+area); 
System.out.println("Area of circumferance -"+circumferance);
}
} 


