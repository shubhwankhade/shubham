class Exp1{
public static void main(String arg[])
{
int x=10, y;
y=x*x+3*x-7;
System.out.println(y);
}
}