class Max_no{

int cond()
{
int arr[] = { 10, 38, 24 };

for(int i=1;i<arr.length;i++)
{
if (arr[0] < arr[i])
{
	arr[0] = arr[i];
} 

}
return arr[0];
} 


static int tar()
{

int a=10;
int b=20;
int c=15;
int max1, max2; 

max1 = a>b?a:b;
max2 = c>max1?c:max1;

return max2;
}
 



public static void main (String args []){


Max_no m = new Max_no();
System.out.println(m.cond());  
System.out.println((tar()));
}
}