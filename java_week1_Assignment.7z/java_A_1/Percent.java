import java.util.Scanner;
class Percent{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
System.out.println("enter marathi marks");
Double marathi = sc.nextDouble();
System.out.println("enter hindi marks");
Double hindi = sc.nextDouble();
System.out.println("enter english marks");
Double english = sc.nextDouble();
System.out.println("enter maths marks");
Double maths  = sc.nextDouble();
System.out.println("enter science marks");
Double science = sc.nextDouble();

Double per = ((marathi+hindi+english+maths+science)*100/500);
System.out.println("percentage marks = "+ per);
}
}