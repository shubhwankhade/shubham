import java.util.Scanner;

class ConCal{

public static void main (String arg []){
int y, d;
Scanner sc = new Scanner(System.in);
int days = sc.nextInt();

	if(days> 365)
	{
	  y = days/365;
	  d = days%365;
	System.out.println(y +" year and "+d+" Days ");
	
	}
	else
	{
		System.out.println("Days are "+days);
	}
}

}
