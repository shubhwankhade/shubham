import java.util.Scanner;
class Temp{
public static void main(String arg []){

Scanner sc = new Scanner(System.in);
double fahrenheit = sc.nextDouble();
float celsius;
 celsius = (float)(5*(fahrenheit -32)/9);
System.out.println("Celsius "+celsius);
}
}