class Assign_Var{

public static void main(String arg []){

int rollNo; 
rollNo = 100;
System.out.println("roll_no = "+rollNo);
}
}