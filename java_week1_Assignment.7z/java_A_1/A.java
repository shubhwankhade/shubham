import java.util.Scanner;
class A{
public static void main (String arg []){
Scanner sc = new Scanner(System.in);
char m = sc.next().charAt(0);
System.out.println(m);
}
}