class Exp1{

void bol()
{
boolean x = true;
boolean y = false;
boolean z = x && y || !(x || y)  ;
System.out.println(z);
}

public static void main(String arg[])
{
int x=10, y, z;
y=x*x+3*x-7;
System.out.println(y);
System.out.println("===========");
y = x++ + ++x;
System.out.println(x);
System.out.println(y);
System.out.println("===========");
z= x++ - --y - --x + x++;
System.out.println(x);
System.out.println(y);
System.out.println(z);
System.out.println("===========");
Exp1 s =new Exp1();
s.bol();
}
}