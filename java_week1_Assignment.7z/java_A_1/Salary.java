import java.util.Scanner;
class Salary{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);
float basic = sc.nextFloat();
float hra;
float da;
double grossSal;
	if(basic<= 10000)
	{
	grossSal = (basic + (basic/10) + (basic*(9/10)));
	System.out.println("Your Gross salary is "+ grossSal);
	
	}

	else
	{
	grossSal = basic + 2000 + (basic*(98/100));		
	System.out.println("Your Gross salary is "+ grossSal);
			
	}

}
}