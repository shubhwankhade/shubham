import java.util.Scanner;
class Swap{
public static void main(String arg []){
Scanner sc = new Scanner(System.in);


int a= sc.nextInt();
int b= sc.nextInt();
a=a+b;
b=a-b;
a=a-b;
System.out.println("==============");
System.out.println(a);
System.out.println(b);
}
}