class F3{
	public static void main(String arg []){
        int c = 0;
	for(int i=1; i<=5; i++)
		
		{
		   for(int j=1; j<=i; j++)
		   {
		     System.out.print(j+" ");
			c = c+j;	
		   }
			
			System.out.print(c);
			c=0;
		        System.out.println();
		}
	}
	}