public class sum_1 {
    public static void main(String[] argv){
        
        System.out.println(74+36);

    }
    }