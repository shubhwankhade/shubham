class rect{
	public static void main(String arg[]){
	int wd, ht, area, peri;
	wd = 4;
	ht = 8;
	area = (wd*ht);
	System.out.println("Area of rectangle "+area);
	peri = 2*(wd+ht);
	System.out.println("Perimeter of rectangle "+peri);
 }
 }