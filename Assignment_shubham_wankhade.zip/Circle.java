class Circle{
	public static void main(String arg[]){
	float r =7.5f; 
	float pi = 3.14f;
	float area, par;
	area = (pi*r*r);
	par = (2*pi*r);
	System.out.println("area "+area);
	System.out.println("Parameter "+par);
}
}