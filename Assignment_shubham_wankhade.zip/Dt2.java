import java.util.Scanner;
class Dt2{
public static void main (String args[]){
	int a, b;
	int sum;

	Scanner sc = new Scanner(System.in);
	System.out.println("Enter no1.");
	a = sc.nextInt();
	System.out.println("Enter no2.");
	b = sc.nextInt();
	sc.close();
	sum = a+b;
	System.out.println("sum = "+sum);
	}
	}