import java.util.Scanner;

class Sum{
	public static void main(String arg[]){
	float a, b, c;
	Scanner sc = new Scanner(System.in);
	System.out.println("add no");
	a = sc.nextFloat();
	System.out.println("add no");
	b = sc.nextFloat();
	c = a+b;
	System.out.println("sum = "+c);
}
}