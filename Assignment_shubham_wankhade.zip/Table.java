import java.util.Scanner;
class Table{
	public static void main(String arg[]){
	int a;
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter no ");
	a = sc.nextInt();
	for(int i=1; i<=10; i++)
	{
	 System.out.println(a*i);
	}
}
}