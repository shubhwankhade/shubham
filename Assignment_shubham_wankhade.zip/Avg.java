import java.util.Scanner;
class Avg{
	public static void main(String arg[]){
	int n = 3;
	int num1, num2, num3;
	float avg;
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter the value ");
	num1 = sc.nextInt();
	System.out.print("Enter the value ");
	num2 = sc.nextInt();
	System.out.print("Enter the value ");
	num3 = sc.nextInt();
	avg = ((num1+num2+num3)/3);
	System.out.println("Average of these value "+avg);
}
}