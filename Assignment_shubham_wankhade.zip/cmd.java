class cmd{
	public static void main(String argv[]){
	
	String s1 = argv[0];
	String s2 = argv[1];
	int i = Integer.parseInt(s1);
	int j = Integer.parseInt(s2);
	int k = i+j;
	System.out.println("Addition of two no is "+k);
	
	}
	}

