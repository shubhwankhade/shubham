public class Div {
    public static void main(String[] argv){
        
        System.out.println(50/3);

    }
    }