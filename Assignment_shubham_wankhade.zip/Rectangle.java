class Rectangle {
	static float l = 8.5f;
	static float w = 5.5f;
	public static void main(String[] args){
		float area = l*w ;
		float perimeter = (2*(l+w));
		System.out.println("area of rectangle =  "+ area);
		System.out.println("Perimeter of rectangle =  "+ perimeter);
}

}



