import java.util.Scanner;
class Cal_1{
	public static void main(String arg[]){
	int num1, num2, sum, sub, mul, div, mod;
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the no.");
	num1 = sc.nextInt();
	System.out.println("enter the no.");
	num2 = sc.nextInt();
	sum = num1+num2;
	sub = num1-num2;
	mul = num1*num2;
	div = num1/num2;
	mod = num1%num2;
	System.out.println("Sum "+sum);
	System.out.println("Sub "+sub);
	System.out.println("Mult "+mul);
	System.out.println("Div "+div);
	System.out.println("mod "+mod);
}
}


