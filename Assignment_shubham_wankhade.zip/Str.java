class Str{
	public static void main(String arg[]){
	String s1 = "My name is,";
	String s2 = new String("Shubham Wankhade"); 
	String s4 = "I am from Washim_karanja Lad";
	char[] s3 ={'a', 'b', 'c'};
	System.out.println(s1);
	System.out.println(s2);
	System.out.println(s4);
	System.out.println(s3);
	}
	}