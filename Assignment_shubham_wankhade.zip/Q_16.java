class Q_16{
	public static void main(String arg []){
	System.out.println(" +\"\"\"\"\"+");
	System.out.println("[| o o |]");
	System.out.println(" |  ^  | ");
	System.out.println(" | '-' | ");
	System.out.println(" +-----+");
	  }
	}