import java.util.Scanner;
class Add{
	public static void main(String argv[]){
	
	int num1, num2, sum;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the value ");
	num1= sc.nextInt();
	System.out.println("Entar the next value ");
	num2= sc.nextInt();
	sum = num1+ num2;
	System.out.println("Sum = "+sum);
	}
	}
	