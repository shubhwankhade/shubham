class Rectangle {
	static double l = 7.5d;
	static float w = 3.14f;
	public static void main(String[] args){
		double area = (l*w);
		double perimeter = 2(l*w);
		System.out.println("area of rectangle"+ area);
		System.out.println("Perimeter of rectangle "+ perimeter);
}

}



