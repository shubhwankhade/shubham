class Downcasting{
	public static void main(String [] arg){
	double d = 10.24d;
	int a ;
	a = (int)d;
	System.out.println(a);
	
}

}


