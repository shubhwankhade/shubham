import java.util.Scanner;
class Swap{
	public static void main(String arg[]){
	
	int num1, num2,temp ;
	
	Scanner sc = new Scanner(System.in);
	System.out.print("num1 value ");
	num1 = sc.nextInt();
	System.out.print("num2 value ");
	num2 = sc.nextInt();
	temp = num1;
	num1 = num2;
	num2 = temp;
	System.out.println("num1 value "+num1);
	System.out.println("num2 value "+num2);
}
}