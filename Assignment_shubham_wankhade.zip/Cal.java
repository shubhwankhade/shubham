class Cal{
	public static void main(String arg[]){
	float a = 22f;
	float b = 4f;
	float sum, sub, mult, div;
	sum = a+b;
	sub = a-b;
	mult= a*b;
	div = a/b;
	
	System.out.println(sum);
	System.out.println(sub);
	System.out.println(mult);
	System.out.println(div);
	
}
}