import java.util.Scanner;
class Mult{
	public static void main(String arg[]){
	int a, b, ans;
	Scanner sc = new Scanner(System.in);
	System.out.println("enter no");
	a = sc.nextInt();
	System.out.println("enter no");
	b = sc.nextInt();
	ans = a*b;
	System.out.println("Multiplication of no "+ans);
}
}