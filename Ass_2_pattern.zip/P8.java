class P8{
	public static void main(String arg[]){
	
	for(int i=6;i>=1;i--)
	{

		for(int k=1;k<=i;k++)
		{	
		System.out.print("*");
		}
	System.out.println();
	}

}
}